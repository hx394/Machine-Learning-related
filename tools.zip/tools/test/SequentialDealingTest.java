import org.junit.Before;
import org.junit.Test;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

import model.Stock;
import model.SuperPortfolio;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * This is a super portfolio test class for assignment 5 features.
 */
public class SequentialDealingTest {


  private SuperPortfolio sp;

  private SuperPortfolio sp2;






  @Before
  public void setUp() {
    this.sp = new SuperPortfolio();
    this.sp2= new SuperPortfolio();
  }

  @Test
  public void sequentialDealing(){
     ArrayList<Integer> naive=new ArrayList<>();
     ArrayList<String> dates=new ArrayList<>();
     ArrayList<Integer> strat=new ArrayList<>();
    String s="stock symbol";

    String filePath = "path/to/your/file.txt"; // 文件路径

    try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
      String line;
      while ((line = br.readLine()) != null) {
        if(line.toLowerCase().charAt(0)=='n') {
          dates.add(line.substring(line.length() - 10));
          naive.add(-1);
        } else if (line.toLowerCase().charAt(0)=='p') {
          dates.add(line.substring(line.length() - 10));
          naive.add(1);
        }

      }
    } catch (IOException e) {
      e.printStackTrace();
    }

    String filePath2 = "path/to/your/file.txt"; // 文件路径

    try (BufferedReader br = new BufferedReader(new FileReader(filePath2))) {
      String line;

      while ((line = br.readLine()) != null) {
        strat.add(Integer.parseInt(line));
      }
    } catch (IOException e) {
      e.printStackTrace();
    }

    Collections.reverse(naive);
    Collections.reverse(strat);
    Collections.reverse(dates);
    double soldStockValue=0.0;
    double soldStockValue2=0.0;
    for(int i=0;i<dates.size();i++){
      if(naive.get(i)==1){
        sp.addStock(s,100,LocalDate.parse(dates.get(i)));
        if(strat.get(i)=='1'){
          sp2.addStock(s,100,LocalDate.parse(dates.get(i)));
        }
      }

      try {
        if (naive.get(i) == -1) {
          Stock st = Stock.getBuilder().symbol(s).shares(100)
                  .timeStamp(LocalDate.now()).build2();
          sp.sellStock(s, 100, LocalDate.parse(dates.get(i)));
          soldStockValue+=100*st.getHistoricalPrice(LocalDate.parse(dates.get(i)));
          if (strat.get(i) == '1') {
            sp2.sellStock(s, 100, LocalDate.parse(dates.get(i)));
            soldStockValue2+=100*st.getHistoricalPrice(LocalDate.parse(dates.get(i)));
          }
        }
      }catch (IllegalArgumentException e){
        System.out.println("Not enough to sell on "+ dates.get(i));
      }

    }
    System.out.println("Naive cost basis:");
    System.out.println(sp.costBasis(LocalDate.parse(dates.get(dates.size()-1))));
    System.out.println("Naive Sold stock value:");
    System.out.println(soldStockValue);
    System.out.println("Naive Value at the end date:");
    System.out.println(sp.getValueByDate(LocalDate.parse(dates.get(dates.size()-1))));
    System.out.println("Naive total benefits:");
    double sum=soldStockValue+sp.getValueByDate(LocalDate.parse(dates.get(dates.size()-1)))
            -sp.costBasis(LocalDate.parse(dates.get(dates.size()-1)));
    System.out.println(sum);
    System.out.println("Strategy cost basis:");
    System.out.println(sp2.costBasis(LocalDate.parse(dates.get(dates.size()-1))));
    System.out.println("Strategy sold stock value:");
    System.out.println(soldStockValue2);
    System.out.println("Strategy Value at the end date:");
    System.out.println(sp2.getValueByDate(LocalDate.parse(dates.get(dates.size()-1))));
    System.out.println("Strategy total benefits:");
    double sum2=soldStockValue2+sp2.getValueByDate(LocalDate.parse(dates.get(dates.size()-1)))
            -sp2.costBasis(LocalDate.parse(dates.get(dates.size()-1)));
    System.out.println(sum2);

  }

  @Test
  public void outputY(){
    ArrayList<Integer> naive=new ArrayList<>();
    ArrayList<String> dates=new ArrayList<>();
    String s="stock symbol";

    String filePath = "path/to/your/file.txt"; // 文件路径

    try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
      String line;
      while ((line = br.readLine()) != null) {
        if(line.toLowerCase().charAt(0)=='n') {
          dates.add(line.substring(line.length() - 10));
          naive.add(-1);
        } else if (line.toLowerCase().charAt(0)=='p') {
          dates.add(line.substring(line.length() - 10));
          naive.add(1);
        }

      }
    } catch (IOException e) {
      e.printStackTrace();
    }



    Collections.reverse(naive);

    Collections.reverse(dates);


    ArrayList<Integer> yyyy=new ArrayList<>();
    Stock stTemp = Stock.getBuilder().symbol(s).shares(1)
            .timeStamp(LocalDate.now()).build2();
    for(int i=0;i<dates.size()-1;i++) {
      String current=stTemp.gainOrLoseOverPeriodOfTime(LocalDate.parse(dates.get(i)),LocalDate.parse(dates.get(i+1)));
      if(current.charAt(0)=='G'){
        yyyy.add(1);
      }else if(current.charAt(0)=='L'){
        yyyy.add(-1);
      }else{
        yyyy.add(0);
      }
    }
    String filePathYYYY = "outputYYYYY.txt";

    try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePathYYYY))) {
      for (int line : yyyy) {
        writer.write(""+line);
        writer.newLine(); // 换行
      }
      System.out.println("ArrayList 已成功写入文件！");
    } catch (IOException e) {
      System.out.println("文件写入错误: " + e.getMessage());
    }


  }



  @Test
  public void testAddStock() {
    sp.addStock("AAPL", 100, LocalDate.parse("2024-03-14"));
    sp.addStock("IBM", 1000, LocalDate.parse("2024-03-08"));
    assertTrue(sp.showPortfolio().contains("IBM"));
    assertTrue(sp.showPortfolio().contains("AAPL"));
  }

  @Test
  public void testSellStock() {
    sp.addStock("AAPL", 100, LocalDate.parse("2024-03-14"));
    sp.addStock("IBM", 1000, LocalDate.parse("2024-03-08"));
    sp.sellStock("IBM", 900, LocalDate.parse("2024-03-11"));
    sp.sellStock("AAPL", 90, LocalDate.parse("2024-03-14"));

    assertTrue(sp.showPortfolio().contains("shares:100"));
    assertTrue(sp.showPortfolio().contains("shares:-900"));
    assertTrue(sp.showPortfolio().contains("shares:-90"));
    assertTrue(sp.showPortfolio().contains("shares:1000"));
  }

  @Test(expected = IllegalArgumentException.class)
  public void testSellStockAtIncorrectDate() {
    sp.addStock("AAPL", 100, LocalDate.parse("2024-03-14"));
    sp.addStock("IBM", 1000, LocalDate.parse("2024-03-08"));
    sp.sellStock("IBM", 900, LocalDate.parse("2024-03-07"));

  }

  @Test(expected = IllegalArgumentException.class)
  public void testSellStockAtMoreSharesCurrentlyHave() {
    sp.addStock("AAPL", 100, LocalDate.parse("2024-03-14"));
    sp.addStock("IBM", 1000, LocalDate.parse("2024-03-08"));
    sp.sellStock("IBM", 1000, LocalDate.parse("2024-03-09"));
    sp.sellStock("IBM", 1, LocalDate.parse("2024-03-08"));

  }

  @Test
  public void testCostBasis() {
    sp.addStock("AAPL", 100, LocalDate.parse("2024-03-14"));
    sp.addStock("IBM", 1000, LocalDate.parse("2024-03-08"));
    sp.sellStock("IBM", 900, LocalDate.parse("2024-03-11"));
    sp.sellStock("AAPL", 90, LocalDate.parse("2024-03-14"));
    sp.addStock("AAPL", 100, LocalDate.parse("2024-03-15"));
    sp.addStock("IBM", 1000, LocalDate.parse("2024-03-07"));
    assertEquals(409790, sp.costBasis(LocalDate.parse("2024-03-14")), 0.01);
  }

  @Test
  public void testGetValueByDate() {
    sp.addStock("AAPL", 100, LocalDate.parse("2024-03-14"));
    sp.addStock("IBM", 1000, LocalDate.parse("2024-03-08"));
    sp.sellStock("IBM", 900, LocalDate.parse("2024-03-11"));
    sp.sellStock("AAPL", 90, LocalDate.parse("2024-03-14"));
    sp.addStock("AAPL", 100, LocalDate.parse("2024-03-15"));
    sp.addStock("IBM", 1000, LocalDate.parse("2024-03-07"));
    double result = sp.getValueByDate(LocalDate.parse("2024-03-11"));
    double result2 = sp.getValueByDate(LocalDate.parse("2024-03-10"));
    double result3 = sp.getValueByDate(LocalDate.parse("2024-03-01"));
    assertEquals(210903, result, 0.01);
    assertEquals(391900, result2, 0.01);
    assertEquals(0, result3, 0.01);
  }

  @Test
  public void testWeightInvestmentOnSpecificDate() {
    HashMap<String, Double> hashmap = new HashMap<>();
    hashmap.put("AAPL", 0.1);
    hashmap.put("IBM", 0.25);
    hashmap.put("GOOG", 0.65);
    sp.weightInvestment(hashmap, LocalDate.parse("2024-04-01"), 100000);
    assertTrue(sp.showPortfolio()
            .contains("shares:415.34 initial price:156.5 trade time:2024-04-01"));
    assertTrue(sp.showPortfolio()
            .contains("shares:58.81 initial price:170.03 trade time:2024-04-01"));
    assertTrue(sp.showPortfolio()
            .contains("shares:131.7 initial price:189.83 trade time:2024-04-01"));
    assertTrue(sp.showPortfolio().contains("GOOG"));
    assertTrue(sp.showPortfolio().contains("IBM"));
    assertTrue(sp.showPortfolio().contains("AAPL"));
  }

  @Test(expected = IllegalArgumentException.class)
  public void testWeightInvestmentIncorrectSymbol() {
    HashMap<String, Double> hashmap = new HashMap<>();
    hashmap.put("NotAStock", 1.0);
    sp.weightInvestment(hashmap, LocalDate.parse("2024-04-01"), 100000);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testWeightInvestmentIncorrectDate() {
    HashMap<String, Double> hashmap = new HashMap<>();
    hashmap.put("AAPL", 0.1);
    hashmap.put("IBM", 0.25);
    hashmap.put("GOOG", 0.65);
    sp.weightInvestment(hashmap, LocalDate.parse("2024-03-31"), 100000);
  }

  @Test
  public void testWeightInvestmentOnSpecificPeriod() {
    HashMap<String, Double> hashmap = new HashMap<>();
    hashmap.put("AAPL", 0.1);
    hashmap.put("IBM", 0.25);
    hashmap.put("GOOG", 0.65);
    sp.weightInvestmentStartToFinish(hashmap, LocalDate.parse("2024-03-12"),
            LocalDate.parse("2024-04-01"), 100000, 5);
    assertTrue(sp.showPortfolio().contains("GOOG"));
    assertTrue(sp.showPortfolio().contains("IBM"));
    assertTrue(sp.showPortfolio().contains("AAPL"));
    //System.out.println(sp.showPortfolio());
    assertTrue(sp.showPortfolio()
            .contains("shares:465.55 initial price:139.62 trade time:2024-03-12"));
    assertTrue(sp.showPortfolio()
            .contains("shares:57.73 initial price:173.23 trade time:2024-03-12"));
    assertTrue(sp.showPortfolio()
            .contains("shares:126.4 initial price:197.78 trade time:2024-03-12"));
    assertTrue(sp.showPortfolio()
            .contains("shares:437.77 initial price:148.48 trade time:2024-03-18"));
    assertTrue(sp.showPortfolio()
            .contains("shares:57.56 initial price:173.72 trade time:2024-03-18"));
    assertTrue(sp.showPortfolio()
            .contains("shares:130.42 initial price:191.69 trade time:2024-03-18"));
    assertTrue(sp.showPortfolio()
            .contains("shares:430.04 initial price:151.15 trade time:2024-03-25"));
    assertTrue(sp.showPortfolio()
            .contains("shares:58.53 initial price:170.85 trade time:2024-03-25"));
    assertTrue(sp.showPortfolio()
            .contains("shares:132.42 initial price:188.79 trade time:2024-03-25"));
    assertTrue(sp.showPortfolio()
            .contains("shares:415.34 initial price:156.5 trade time:2024-04-01"));
    assertTrue(sp.showPortfolio()
            .contains("shares:58.81 initial price:170.03 trade time:2024-04-01"));
    assertTrue(sp.showPortfolio()
            .contains("shares:131.7 initial price:189.83 trade time:2024-04-01"));
  }

}
